"""Radiant Voices"""

__version__ = "1.1.0"

ENCODING = "utf8"
