def base2_to_base10(i):
    return i * 100 // 256
